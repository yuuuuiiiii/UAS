<?php  
session_start();
$server="localhost";
$user="root";
$pass=""; // set your own password here
$db="hms";

//Koneksi dan Menentukan Database Di Server
$conn = new mysqli($server, $user, $pass, $db);
if (!$conn) {
    die("KONEKSI GAGAL: " . $conn->connect_error());
}
error_reporting(E_ALL);
?>

<script type="text/javascript">
window.print() 
</script>

<style type="text/css">
#print {
	margin:auto;
	text-align:center;
	font-family:"Calibri", Courier, monospace;
	width:1200px;
	font-size:14px;
}
#print .title {
	margin:20px;
	text-align:right;
	font-family:"Calibri", Courier, monospace;
	font-size:12px;
}
#print span {
	text-align:center;
	font-family:"Trebuchet MS", Arial, Helvetica, sans-serif;	
	font-size:18px;
}
#print table {
	border-collapse:collapse;
	width:100%;
	margin:10px;
}
#print .table1 {
	border-collapse:collapse;
	width:90%;
	text-align:center;
	margin:10px;
}
#print table hr {
	border:3px double #000;	
}
#print .ttd {
	float:right;
	width:250px;
	background-position:center;
	background-size:contain;
}
#print table th {
	color:#000;
	font-family:Verdana, Geneva, sans-serif;	
	font-size:12px;
}
#logo{
	width:111px;
	height:90px;
	padding-top:10px;	
	margin-left:10px;
}

h2,h3{
	margin: 0px 0px 0px 0px;
}
</style>

<title>Laporan Cetak</title>
<div id="print">
	<table class='table1'>
		<tr>
        <td><img src='ex1.jpg' height="100" width="100"></td>
		<td>
		<h2>MANAJEMEN RUMAH SAKIT FARELL</h2>
		<h2>By FAREL BABIBILAH</h2>
		<p style="font-size:14px;"><i> KOTA JAMBI SEKITAR</i></p>
		</td>
	</tr>
</table>

<table class='table'>	
<td><hr /></td>

</table>
<td><h3>LAPORAN RIWAYAT PENGANGKATAN</h3></td>
<tr>
<td>
<table border='1' class='table' width="90%">
<tr>
<th width="30">No.</th>
<td>dokter</td>
<td>Nama Pasien</td>
<td>Spesialis</td>
<td>Biaya kunsultasi</td>
<td>Tanggal/Waktu Pengangkatan</td> 
<td>Tanggal Pembuatan Janji Temu</td>
</tr>
<?php 
$data = $conn->query("select doctors.doctorName as docname,users.fullName as pname,appointment.*  from appointment join doctors on doctors.id=appointment.doctorId join users on users.id=appointment.userId ");
$q=0;
while ($row = $data->fetch_array()) {
$q++;?>
<tr>
<td><center><?php echo $q; ?></center></td>
<td>&nbsp;&nbsp;<?php echo $row['docname']; ?></td>
<td>&nbsp;&nbsp;<?php echo $row['pname'] ?></td>
<td>&nbsp;&nbsp;<?php echo $row['doctorSpecialization'] ?></td>
<td>&nbsp;&nbsp;<?php echo $row['consultancyFees'] ?></td>
<td>&nbsp;&nbsp;<?php echo $row['appointmentDate'] ?></td>
<td>&nbsp;&nbsp;<?php echo $row['appointmentTime'] ?></td>
</tr>
<?php } ?>
</table>
</tr>
</table>
</div>
<div id="print">
<table width="450" align="right" class="ttd">
<tr>
<td width="100px" style="padding:20px 20px 20px 20px;" align="center">
<strong>KEPALA RS</strong>
      <br><br><br><br>
<strong><u>Tanda Tangan</u><br></strong><small></small>
</td>
</tr>
</table>
</div>